/** Automatically generated file. DO NOT MODIFY */
package com.smapp.wedelis;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}